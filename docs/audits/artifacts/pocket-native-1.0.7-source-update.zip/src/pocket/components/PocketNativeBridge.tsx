import { dispatchPocketNativeBack } from '../lib/pocketNativeBack'
import {useTheme} from '../../lib/ThemeContext'
import { createPocketNativeLinkRouter } from '../lib/pocketNativeLinks'
import { useEffect, useRef, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { App as CapacitorApp } from '@capacitor/app'
import { Network } from '@capacitor/network'
import { StatusBar, Style } from '@capacitor/status-bar'
import { registerPlugin } from '@capacitor/core'
import { isPocketNativeRuntime, POCKET_BASE_PATH } from '../lib/pocketRoutes'


type PocketNativeInsets = { top: number; bottom: number; topPx?: number; bottomPx?: number; density?: number }
const PocketInsets = registerPlugin<{
  setPocketTheme(options: {dark:boolean}): Promise<void>
  getInsets(): Promise<PocketNativeInsets>
  setSystemBarAppearance(options: { darkIcons: boolean; navigationDarkIcons?: boolean; backgroundColor: string }): Promise<void>
}>('PocketInsets')

function nativeInsetCssPixels(value: number | undefined, pixels: number | undefined, density: number | undefined) {
  if (Number.isFinite(pixels) && Number.isFinite(density) && Number(density) > 0) {
    return Math.max(0, Math.round(Number(pixels) / Number(density)))
  }
  const measured = Math.max(0, Number(value) || 0)
  const ratio = Math.max(1, window.devicePixelRatio || 1)
  return measured > 48 && ratio > 1 ? Math.round(measured / ratio) : Math.round(measured)
}

export default function PocketNativeBridge() {
  const {theme}=useTheme()
  useEffect(()=>{if(isPocketNativeRuntime())void PocketInsets.setPocketTheme({dark:theme==='dark'}).catch(()=>undefined)},[theme])
  const navigate = useNavigate()
  const navigateRef = useRef(navigate)
  navigateRef.current = navigate
  const location = useLocation()
  const currentPath = useRef(location.pathname)
  currentPath.current = location.pathname
  useEffect(() => {
    if (!isPocketNativeRuntime()) return
    let disposed = false
    let remove: (() => Promise<void>) | undefined
    const listener = CapacitorApp.addListener('backButton', ({ canGoBack }) => {
      const path = currentPath.current.slice(POCKET_BASE_PATH.length) || '/'
      dispatchPocketNativeBack({
        atHome: ['/', '/home'].includes(path),
        canGoBack,
        back: () => navigateRef.current(-1),
        home: () => navigateRef.current(POCKET_BASE_PATH + '/home', { replace: true }),
        minimize: () => { void CapacitorApp.minimizeApp() },
      })
    })
    void listener.then(handle => { if (disposed) void handle.remove(); else remove = () => handle.remove() }).catch(() => undefined)
    return () => { disposed = true; if (remove) void remove().catch(() => undefined) }
  }, [])
  const [online, setOnline] = useState(true)

  useEffect(() => {
    if (!isPocketNativeRuntime()) return
    let active = true
    const listeners: Array<Promise<{ remove: () => Promise<void> }>> = []
    const links = createPocketNativeLinkRouter((path, options) => navigateRef.current(path, options))

    // Android 16 enforces edge-to-edge and ignores overlaysWebView. Read the
    // native inset and expose it to CSS instead of trusting env() alone.
    const syncInsets = () => void PocketInsets.getInsets().then(info => {
      if (!active) return
      document.documentElement.style.setProperty('--pocket-status-bar-inset', `${nativeInsetCssPixels(info.top, info.topPx, info.density)}px`)
      document.documentElement.style.setProperty('--pocket-navigation-bar-inset', `${nativeInsetCssPixels(info.bottom, info.bottomPx, info.density)}px`)
    }).catch(() => StatusBar.getInfo().then(info => {
      if (active) document.documentElement.style.setProperty('--pocket-status-bar-inset', `${Math.max(0, Math.round((info.height || 0) / Math.max(1, window.devicePixelRatio || 1)))}px`)
    }).catch(() => undefined))
    syncInsets()
    window.addEventListener('resize', syncInsets)
    window.addEventListener('orientationchange', syncInsets)
    const syncStatusBar = () => {
      const lightSurface = document.documentElement.dataset.pocketLightSurface === 'true'
      const navigationDarkIcons = lightSurface || !document.documentElement.classList.contains('dark')
      const darkIcons = lightSurface || (document.documentElement.dataset.pocketSupportSurface === 'home' ? false : navigationDarkIcons)
      const style = darkIcons ? Style.Light : Style.Dark
      void StatusBar.setStyle({ style }).catch(() => undefined)
      void PocketInsets.setSystemBarAppearance({ darkIcons, navigationDarkIcons, backgroundColor: navigationDarkIcons ? '#F5F5F7' : '#000000' }).catch(() => undefined)
    }
    syncStatusBar()
    const themeObserver = new MutationObserver(syncStatusBar)
    themeObserver.observe(document.documentElement, { attributes: true, attributeFilter: ['class', 'data-pocket-light-surface', 'data-pocket-support-surface'] })
    void Network.getStatus().then(status => {
      if (active) setOnline(status.connected)
    }).catch(() => undefined)

    listeners.push(Network.addListener('networkStatusChange', status => {
      if (active) setOnline(status.connected)
    }))
    listeners.push(CapacitorApp.addListener('appUrlOpen', event => {
      links.event(event.url)
    }))
    listeners.push(CapacitorApp.addListener('appStateChange', state => {
      if (state.isActive) {
        syncInsets()
        syncStatusBar()
        window.dispatchEvent(new Event('focus'))
        document.dispatchEvent(new Event('visibilitychange'))
      }
    }))

    void CapacitorApp.getLaunchUrl().then(result => {
      if (result?.url) links.launch(result.url)
    }).catch(() => undefined)

    return () => {
      active = false
      links.dispose()
      window.removeEventListener('resize', syncInsets)
      window.removeEventListener('orientationchange', syncInsets)
      document.documentElement.style.removeProperty('--pocket-status-bar-inset')
      document.documentElement.style.removeProperty('--pocket-navigation-bar-inset')
      themeObserver.disconnect()
      for (const listener of listeners) void listener.then(handle => handle.remove()).catch(() => undefined)
    }
  }, [])

  if (!isPocketNativeRuntime() || online) return null
  return (
    <div className="fixed inset-x-0 top-0 z-[100] bg-gray-950 px-4 pb-2 pt-[max(0.5rem,var(--pocket-safe-top))] text-center text-[11px] font-semibold text-white dark:bg-white dark:text-gray-950">
      Offline - balances and activity will update when you reconnect
    </div>
  )
}
