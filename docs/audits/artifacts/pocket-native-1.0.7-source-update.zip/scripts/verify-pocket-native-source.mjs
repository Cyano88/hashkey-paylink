import fs from 'node:fs';import crypto from 'node:crypto';
const root=new URL('../',import.meta.url);
const baseline=JSON.parse(fs.readFileSync(new URL('native-release/source-baseline.json',root),'utf8'));
const policy=JSON.parse(fs.readFileSync(new URL('native-release/source-policy.json',root),'utf8'));
const changed=[],missing=[];
for(const [p,hash] of Object.entries(baseline.files)){
 if(policy.allowedChanges.includes(p) || p.startsWith("android/app/src/main/assets/"))continue;
 const file=new URL(p,root);if(!fs.existsSync(file)){missing.push(p);continue}
 if(crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex')!==hash)changed.push(p);
}
if(changed.length||missing.length)throw Error('Native baseline changed outside the reviewed fix: '+JSON.stringify({changed,missing}));
console.log('PASS verified original Pocket lineage: protected source, artwork, animation assets and feature configuration unchanged.');
