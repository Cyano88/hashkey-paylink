package com.hashpaylink.pocket;

import android.os.Bundle;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.ColorDrawable;
import android.webkit.JavascriptInterface;
import androidx.core.splashscreen.SplashScreen;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    private volatile boolean keepLaunchSplash = true;
    private androidx.core.splashscreen.SplashScreenViewProvider launchProvider;
    private boolean launchReleasePending;
    private boolean launchCompleted;

    @Override
    protected void attachBaseContext(Context base) {
        android.content.SharedPreferences prefs = base.getSharedPreferences("pocket-appearance", MODE_PRIVATE);
        if (prefs.contains("dark")) {
            Configuration config = new Configuration(base.getResources().getConfiguration());
            config.uiMode = (config.uiMode & ~Configuration.UI_MODE_NIGHT_MASK) | (prefs.getBoolean("dark", false) ? Configuration.UI_MODE_NIGHT_YES : Configuration.UI_MODE_NIGHT_NO);
            base = base.createConfigurationContext(config);
        }
        super.attachBaseContext(base);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        SplashScreen launchSplash = SplashScreen.installSplashScreen(this);
        launchSplash.setKeepOnScreenCondition(() -> keepLaunchSplash);
        launchSplash.setOnExitAnimationListener(provider -> {
            // Warm launches must not reuse the cold-start animation callback.
            if (launchCompleted || launchReleasePending) {
                provider.remove();
                clearLaunchExitListener();
                return;
            }
            launchProvider = provider;
            getWindow().getDecorView().postDelayed(this::releaseLaunch, 2000);
            WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
            // Apply edge-to-edge bounds behind the native artwork before revealing
            // the WebView. Otherwise its first visible frame uses the old insets.
            getWindow().getDecorView().requestApplyInsets();
            long began = provider.getIconAnimationStartMillis();
            getWindow().getDecorView().postOnAnimation(() -> {
                float motionScale = android.provider.Settings.Global.getFloat(getContentResolver(), android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1f);
                long elapsed = began > 0 && motionScale > 0 ? (long)(Math.max(0, System.currentTimeMillis() - began) / motionScale * 0.5) : 980;
                getBridge().getWebView().evaluateJavascript(
                    "window.dispatchEvent(new CustomEvent('pocket-launch-ready',{detail:{elapsed:" + elapsed + ",rate:" + (motionScale > 0 ? 0.5f / motionScale : 1f) + "}}))",
                    null
                );
            });
        });
        registerPlugin(PocketInsetsPlugin.class);
        registerPlugin(PocketHapticsPlugin.class);
        registerPlugin(PocketClipboardPlugin.class);
        registerPlugin(PocketStatementPlugin.class);
        registerPlugin(PocketReceiptPlugin.class);
        registerPlugin(PocketEsimPlugin.class);
        super.onCreate(savedInstanceState);
        getBridge().getWebView().addJavascriptInterface(new PocketLaunchBridge(), "PocketLaunch");
        getBridge().getWebView().postDelayed(() -> keepLaunchSplash = false, 15_000);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        WindowInsetsControllerCompat controller = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        boolean lightBars = getResources().getBoolean(R.bool.pocket_light_system_bars);
        controller.setAppearanceLightStatusBars(lightBars);
        controller.setAppearanceLightNavigationBars(lightBars);
        int surface = androidx.core.content.ContextCompat.getColor(this, R.color.pocket_launch_background);
        getWindow().setBackgroundDrawableResource(R.drawable.pocket_launch_window_background);
        getBridge().getWebView().setBackgroundColor(surface);
    }

    private void releaseLaunch() {
        if (launchProvider == null || launchReleasePending) return;
        launchReleasePending = true;
        final androidx.core.splashscreen.SplashScreenViewProvider releasingProvider = launchProvider;
        android.view.ViewGroup decor = (android.view.ViewGroup) getWindow().getDecorView();
        android.widget.FrameLayout cover = new android.widget.FrameLayout(this);
        // Keep the WebView compositing beneath this temporary cover.
        cover.setAlpha(0.999f);
        cover.setBackgroundColor(androidx.core.content.ContextCompat.getColor(this, R.color.pocket_launch_background));
        android.widget.ImageView mark = new android.widget.ImageView(this);
        mark.setImageResource(R.drawable.pocket_launch_settled);
        int size = Math.round(288 * getResources().getDisplayMetrics().density);
        cover.addView(mark, new android.widget.FrameLayout.LayoutParams(size, size, android.view.Gravity.CENTER));
        decor.addView(cover, new android.view.ViewGroup.LayoutParams(-1, -1));
        // The replacement must have drawable bounds in this very frame, before
        // removing the system view. Waiting for its first layout exposes black.
        cover.measure(
            android.view.View.MeasureSpec.makeMeasureSpec(decor.getWidth(), android.view.View.MeasureSpec.EXACTLY),
            android.view.View.MeasureSpec.makeMeasureSpec(decor.getHeight(), android.view.View.MeasureSpec.EXACTLY)
        );
        cover.layout(0, 0, decor.getWidth(), decor.getHeight());
        // Rendering callbacks may stop while backgrounded. Always release the
        // native cover on the UI queue without waiting for a WebView frame.
        decor.postDelayed(() -> {
            if (launchCompleted) return;
            if (launchProvider == releasingProvider) {
                releasingProvider.remove();
                launchProvider = null;
                clearLaunchExitListener();
            }
            finishLaunchCover(decor, cover);
        }, 2500);
        // Commit the cover to a rendered frame before removing the system surface.
        // Layout alone does not submit its pixels to the compositor.
        decor.postOnAnimation(() -> decor.postOnAnimation(() -> {
        if (launchCompleted) return;
        releasingProvider.remove();
        if (launchProvider == releasingProvider) launchProvider = null;
        clearLaunchExitListener();
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        // Keep the last native frame visible while removing the system splash
        // changes WebView insets. Reveal only after that new layout is rendered.
        getBridge().getWebView().postOnAnimation(() -> getBridge().getWebView().postVisualStateCallback(
            1, new android.webkit.WebView.VisualStateCallback() {
                @Override public void onComplete(long requestId) {
                    decor.postOnAnimation(() -> decor.postOnAnimation(() -> {
                        if (!launchCompleted) cover.animate().alpha(0f).setDuration(120)
                            .withEndAction(() -> finishLaunchCover(decor, cover)).start();
                    }));
                }
            }
        ));
        }));
    }

    private void clearLaunchExitListener() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            getSplashScreen().clearOnExitAnimationListener();
        }
    }

    private void finishLaunchCover(android.view.ViewGroup decor, android.widget.FrameLayout cover) {
        if (launchCompleted) return;
        launchCompleted = true;
        keepLaunchSplash = false;
        clearLaunchExitListener();
        cover.animate().cancel();
        if (cover.getParent() == decor) decor.removeView(cover);
        getBridge().getWebView().evaluateJavascript(
            "window.dispatchEvent(new Event('pocket-launch-visible'))", null
        );
    }

    private final class PocketLaunchBridge {
        @JavascriptInterface
        public void painted() {
            runOnUiThread(() -> getBridge().getWebView().postVisualStateCallback(
                0, new android.webkit.WebView.VisualStateCallback() {
                    @Override public void onComplete(long requestId) {
                        releaseLaunch();
                    }
                }
            ));
        }

        @JavascriptInterface
        public void ready() {
            runOnUiThread(() -> keepLaunchSplash = false);
        }
    }
}
